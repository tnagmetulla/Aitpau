package kz.tnagmetulla.kotlinmessenger

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import kotlinx.android.synthetic.main.activity_sign_up.*

class RegisterActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        register_button_registration.setOnClickListener{
            performRegister()
        }
        val intent = Intent(this,SignInActivity::class.java)
        login_textView.setOnClickListener {
            startActivity(intent)
        }
    }

    fun performRegister(){
        val username=username_editText_registration.text
        val email=email_editText_registration.text
        val password=password_editText_registration.text

        Log.d("Register:", "username is: $username")
        Log.d("Register:", "email is: $email")
        Log.d("Register:", "password is: $password")
    }
}
